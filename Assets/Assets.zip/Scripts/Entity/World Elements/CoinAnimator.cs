using NSMB.Utilities;
using NSMB.Utilities.Components;
using NSMB.Utilities.Extensions;
using Quantum;
using Quantum.Profiling;
using UnityEngine;
using static NSMB.Utilities.QuantumViewUtils;

namespace NSMB.Entities.World {
    public unsafe class CoinAnimator : QuantumEntityViewComponent {

        //---Serialized Variables
        [SerializeField] private LegacyAnimateSpriteRenderer defaultCoinAnimate, dottedCoinAnimate;
        [SerializeField] private AudioSource sfx;
        [SerializeField] private SpriteRenderer sRenderer;
        [SerializeField] private ParticleSystem sparkles;
        [SerializeField] private bool looseCoin;

        //---Private Variables
        private bool alreadyBounced;

        public void OnValidate() {
            this.SetIfNull(ref sfx);
            this.SetIfNull(ref sRenderer);
            this.SetIfNull(ref sparkles, UnityExtensions.GetComponentType.Children);
        }

        public void Start() {
            QuantumEvent.Subscribe<EventCoinChangedType>(this, OnCoinChangedType, onlyIfEntityViewBound: true);
            QuantumEvent.Subscribe<EventCoinChangeCollected>(this, OnCoinChangedCollected, onlyIfEntityViewBound: true);
            QuantumEvent.Subscribe<EventCoinBounced>(this, OnCoinBounced, FilterOutReplayFastForward, onlyIfEntityViewBound: true);
            QuantumCallback.Subscribe<CallbackGameResynced>(this, OnGameResynced, onlyIfEntityViewBound: true);
        }

        public override void OnActivate(Frame f) {
            if (!f.Unsafe.TryGetPointer(EntityRef, out Coin* coin)) {
                return;
            }

            bool dotted = coin->IsCurrentlyDotted;
            defaultCoinAnimate.isDisplaying = !dotted;
            dottedCoinAnimate.isDisplaying = dotted;
            sRenderer.enabled = true;
            alreadyBounced = false;

            if (looseCoin) {
                defaultCoinAnimate.frame = UnityEngine.Random.Range(0, defaultCoinAnimate.frames.Length);
                dottedCoinAnimate.frame = UnityEngine.Random.Range(0, dottedCoinAnimate.frames.Length);
            }
        }

        public override void OnDeactivate() {
            sRenderer.enabled = false;

            if (looseCoin) {
                ParticleSystem newSparkles = Instantiate(sparkles, sRenderer.transform.position, Quaternion.identity);
                newSparkles.gameObject.SetActive(true);
                newSparkles.Play();
                Destroy(newSparkles.gameObject, 0.5f);
            }
        }

        public override void OnUpdateView() {
            using var profilerScope = HostProfiler.Start("CoinAnimator.OnUpdateView");
            Frame f = PredictedFrame;
            if (!f.Exists(EntityRef)) {
                return;
            }

            var coin = f.Unsafe.GetPointer<Coin>(EntityRef);
            if (coin->CoinType.HasFlag(CoinType.BakedInStage)) {
                // Bodge: OnCoinChangedCollected doesnt work when collecting a coin at the exact same time as a level reset 
                sRenderer.enabled = !coin->IsCollected;
            } else {
                sRenderer.enabled = Utils.Blink((float) coin->Lifetime / f.UpdateRate, blinksPerSecond: 4f, blinkStartTime: 3f);
            }
        }

        private void OnCoinBounced(EventCoinBounced e) {
            if (e.Entity != EntityRef) {
                return;
            }

            if (alreadyBounced) {
                return;
            }

            sfx.pitch = 1f;
            sfx.volume = 1f;
            sfx.PlayOneShot(SoundEffect.World_Coin_Drop);
            alreadyBounced = true;
        }

        private void OnCoinChangedCollected(EventCoinChangeCollected e) {
            if (e.Entity != EntityRef) {
                return;
            }

            sRenderer.enabled = !e.Collected;
            if (e.Collected && !IsReplayFastForwarding) {
                if (looseCoin) {
                    sparkles.transform.SetParent(transform.parent);
                    sparkles.gameObject.SetActive(true);
                    sparkles.transform.position = sRenderer.transform.position;
                }

                sparkles.Play();
            }
        }

        private void OnCoinChangedType(EventCoinChangedType e) {
            if (e.Entity != EntityRef) {
                return;
            }

            bool dotted = e.Coin.IsCurrentlyDotted;
            defaultCoinAnimate.isDisplaying = !dotted;
            dottedCoinAnimate.isDisplaying = dotted;

            if (!dotted && !IsReplayFastForwarding) {
                sfx.PlayOneShot(SoundEffect.World_Coin_Dotted_Spawn);
            }
        }

        private void OnGameResynced(CallbackGameResynced e) {
            OnActivate(e.Game.Frames.Verified);
        }
    }
}
