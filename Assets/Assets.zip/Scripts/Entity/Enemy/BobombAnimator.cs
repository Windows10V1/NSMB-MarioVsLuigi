using NSMB.Sound;
using NSMB.Utilities;
using NSMB.Utilities.Extensions;
using Quantum;
using UnityEngine;
using static NSMB.Utilities.QuantumViewUtils;

namespace NSMB.Entities.Enemies {
    public unsafe class BobombAnimator : QuantumEntityViewComponent {

        //---Static Variables
        private static readonly int ParamLit = Animator.StringToHash("lit");
        private static readonly int ParamTurnaround = Animator.StringToHash("turnaround");
        private static readonly int ParamFlashAmount = Shader.PropertyToID("FlashAmount");

        //---Serialized Variables
        [SerializeField] private SoundEffectPlayer sfx;
        [SerializeField] private SpriteRenderer sRenderer;
        [SerializeField] private Animator animator;
        [SerializeField] private GameObject explosionPrefab;

        //---Private Variables
        private MaterialPropertyBlock mpb;

        public void OnValidate() {
            this.SetIfNull(ref sRenderer, UnityExtensions.GetComponentType.Children);
            this.SetIfNull(ref animator, UnityExtensions.GetComponentType.Children);
            this.SetIfNull(ref sfx);
        }

        public void Start() {
            QuantumEvent.Subscribe<EventBobombExploded>(this, OnBobombExploded, FilterOutReplayFastForward);
            QuantumEvent.Subscribe<EventBobombLit>(this, OnBobombLit, FilterOutReplayFastForward);
            QuantumEvent.Subscribe<EventPlayComboSound>(this, OnPlayComboSound, FilterOutReplayFastForward);
            QuantumEvent.Subscribe<EventGameEnded>(this, OnGameEnded);
            QuantumCallback.Subscribe<CallbackGameResynced>(this, OnGameResynced);
        }

        public override void OnUpdateView() {
            Frame f = PredictedFrame;
            if (!f.Exists(EntityRef)) {
                return;
            }

            if (f.Global->GameState >= GameState.Ended) {
                animator.speed = 0;
                return;
            }

            var freezable = f.Unsafe.GetPointer<Freezable>(EntityRef);
            if (freezable->IsFrozen(f)) {
                animator.speed = 0;
                sfx.Stop();
                return;
            } else {
                animator.speed = 1;
            }

            var bobomb = f.Unsafe.GetPointer<Bobomb>(EntityRef);
            var enemy = f.Unsafe.GetPointer<Enemy>(EntityRef);
            var holdable = f.Unsafe.GetPointer<Holdable>(EntityRef);

            bool lit = bobomb->CurrentDetonationFrames > 0;
            animator.SetBool(ParamLit, lit);

            if (mpb == null) {
                sRenderer.GetPropertyBlock(mpb = new());
            }
            if (!lit) {
                mpb.SetFloat(ParamFlashAmount, 0);
            } else {
                float detonationTimer = bobomb->CurrentDetonationFrames / 60f;
                float redOverlayPercent = 5.39f / (detonationTimer + 2.695f) * 10f % 1f;
                mpb.SetFloat(ParamFlashAmount, redOverlayPercent);
            }

            // Bodge...
            // Fuck whoever wrote this, they REALLY wanted to mess UP my respawn code >:(
            if (!enemy->IsAlive && enemy->RespawnTimer > enemy->RespawnSparklesTimer + 1) {
                sfx.Stop();
            }

            sRenderer.SetPropertyBlock(mpb);
            sRenderer.enabled = enemy->IsActive;
            sRenderer.flipX = !enemy->FacingRight;

            Vector3 modifiedZ = transform.position;
            if (f.Exists(holdable->Holder)) {
                modifiedZ.z = -4.1f;
            }
            transform.position = modifiedZ;

            if (enemy->IsDead) {
                transform.rotation *= Quaternion.Euler(0, 0, 400f * (enemy->FacingRight ? -1 : 1) * Time.deltaTime);
            } else {
                transform.rotation = Quaternion.identity;
            }
        }

        private void OnGameEnded(EventGameEnded e) {
            sfx.Stop();
        }

        private void OnPlayComboSound(EventPlayComboSound e) {
            if (e.Entity != EntityRef) {
                return;
            }

            sfx.PlayOneShot(QuantumViewUtils.GetComboSoundEffect(e.Combo));
        }

        private void OnBobombExploded(EventBobombExploded e) {
            if (e.Entity != EntityRef) {
                return;
            }

            Instantiate(explosionPrefab, sRenderer.bounds.center, Quaternion.identity);
            sfx.Stop();
        }

        private void OnBobombLit(EventBobombLit e) {
            if (e.Entity != EntityRef) {
                return;
            }

            sfx.Play(SoundEffect.Enemy_Bobomb_Fuse);
        }

        private void OnGameResynced(CallbackGameResynced e) {
            sfx.Stop();
        }
    }
}
