using Photon.Deterministic;
using Quantum.Physics2D;

namespace Quantum {
    public unsafe class PiranhaPlantSystem : SystemMainThreadEntityFilter<PiranhaPlant, PiranhaPlantSystem.Filter>, ISignalOnTileChanged,
        ISignalOnEnemyRespawned, ISignalOnBreakableObjectChangedHeight, ISignalOnIceBlockBroken, ISignalOnStageReset {

        private Shape2D playerProximityShape;

        public struct Filter {
            public EntityRef Entity;
            public Transform2D* Transform;
            public PiranhaPlant* PiranhaPlant;
            public Enemy* Enemy;
            public PhysicsCollider2D* Collider;
            public Interactable* Interactable;
            public Freezable* Freezable;
        }

        public override void OnInit(Frame f) {
            f.Context.Interactions.Register<PiranhaPlant, MarioPlayer>(f, OnPiranhaPlantMarioInteraction);
            f.Context.Interactions.Register<PiranhaPlant, Projectile>(f, OnPiranhaPlantProjectileInteraction);
            f.Context.Interactions.Register<PiranhaPlant, IceBlock>(f, OnPiranhaPlantIceBlockInteraction);
            playerProximityShape = Shape2D.CreateCircle(FP._0_50, FPVector2.Up);
        }

        public override void Update(Frame f, ref Filter filter, VersusStageData stage) {
            var piranhaPlant = filter.PiranhaPlant;
            var transform = filter.Transform;
            var enemy = filter.Enemy;
            var freezable = filter.Freezable;

            if (!enemy->IsAlive
                || freezable->IsFrozen(f)) {
                return;
            }

            bool chomping = piranhaPlant->ChompFrames > 0;
            if (chomping) {
                // Currently chomping.
                if (QuantumUtils.Decrement(ref piranhaPlant->ChompFrames)) {
                    piranhaPlant->WaitingFrames = 216;
                }
            } else {
                // Not chomping, run the countdown timer.
                if (QuantumUtils.Decrement(ref piranhaPlant->WaitingFrames)) {
                    HitCollection playerHits = f.Physics2D.OverlapShape(*transform, playerProximityShape, f.Context.PlayerOnlyMask);
                    if (playerHits.Count == 0) {
                        // No players nearby. pop up.
                        piranhaPlant->ChompFrames = 90;
                    }
                }
            }


            FP change = (chomping ? 2 : -2) * f.DeltaTime;
            piranhaPlant->PopupAnimationTime = FPMath.Clamp01(piranhaPlant->PopupAnimationTime + change);
            filter.Interactable->ColliderDisabled = piranhaPlant->PopupAnimationTime < FP._0_10;
            FPVector2 offset = FPVector2.Up * (FP._0_25 + (piranhaPlant->PopupAnimationTime - 1) * FP._0_75);
            transform->Position = enemy->Spawnpoint + offset;

            freezable->IceBlockSize.Y = Constants._1_10 * piranhaPlant->PopupAnimationTime;
        }

        public void OnPiranhaPlantIceBlockInteraction(Frame f, EntityRef piranhaPlantEntity, EntityRef iceBlockEntity) {
            var piranhaPlant = f.Unsafe.GetPointer<PiranhaPlant>(piranhaPlantEntity);
            var iceBlock = f.Unsafe.GetPointer<IceBlock>(iceBlockEntity);

            piranhaPlant->Kill(f, piranhaPlantEntity, iceBlockEntity, EnemyKillReason.Special);
        }

        public void OnPiranhaPlantProjectileInteraction(Frame f, EntityRef piranhaPlantEntity, EntityRef projectileEntity) {
            var projectileAsset = f.FindAsset(f.Unsafe.GetPointer<Projectile>(projectileEntity)->Asset);
            var piranhaPlant = f.Unsafe.GetPointer<PiranhaPlant>(piranhaPlantEntity);

            switch (projectileAsset.Effect) {
            case ProjectileEffectType.Hammer:
            case ProjectileEffectType.Boomerang:
            case ProjectileEffectType.Superball:
            case ProjectileEffectType.Gold:
            case ProjectileEffectType.Fire: {
                piranhaPlant->Kill(f, piranhaPlantEntity, projectileEntity, EnemyKillReason.Special);
                break;
            }
            case ProjectileEffectType.Freeze: {
                EntityRef newIceBlock = IceBlockSystem.Freeze(f, piranhaPlantEntity);
                var newIceBlockTransform = f.Unsafe.GetPointer<Transform2D>(newIceBlock);
                newIceBlockTransform->Position.Y += (1 - piranhaPlant->PopupAnimationTime) * FP._0_75;
                break;
            }
            }

            f.Signals.OnProjectileHitEntity(projectileEntity, piranhaPlantEntity);
        }

        public void OnPiranhaPlantMarioInteraction(Frame f, EntityRef piranhaPlantEntity, EntityRef marioEntity) {
            var mario = f.Unsafe.GetPointer<MarioPlayer>(marioEntity);
            var marioPhysicsObject = f.Unsafe.GetPointer<PhysicsObject>(marioEntity);

            if (mario->InstakillsEnemies(marioPhysicsObject, false)) {
                var piranhaPlant = f.Unsafe.GetPointer<PiranhaPlant>(piranhaPlantEntity);
                piranhaPlant->Kill(f, piranhaPlantEntity, marioEntity, EnemyKillReason.Special);

            } else if (!mario->IsCrouchedInShell) {
                mario->Powerdown(f, marioEntity, false, piranhaPlantEntity);
            }
        }

        public void OnTileChanged(Frame f, IntVector2 tilePosition, StageTileInstance newTile) {
            var filter = f.Filter<PiranhaPlant, Enemy>();
            VersusStageData stage = f.FindAsset<VersusStageData>(f.Map.UserAsset);

            while (filter.NextUnsafe(out EntityRef entity, out PiranhaPlant* piranhaPlant, out Enemy* enemy)) {
                IntVector2 tile = QuantumUtils.WorldToRelativeTile(stage, enemy->Spawnpoint);
                if (tile.Equals(tilePosition)) {
                    enemy->DisableRespawning = true;
                    if (enemy->IsAlive) {
                        piranhaPlant->Kill(f, entity, EntityRef.None, EnemyKillReason.Special);
                    }
                    enemy->RespawnTimer = 0;
                }
            }
        }

        public void OnEnemyRespawned(Frame f, EntityRef entity) {
            if (f.Unsafe.TryGetPointer(entity, out PiranhaPlant* piranhaPlant)) {
                piranhaPlant->Respawn(f, entity);
            }
        }

        public void OnBreakableObjectChangedHeight(Frame f, EntityRef breakableEntity, FP newHeight) {
            var filter = f.Filter<PiranhaPlant, Enemy>();
            while (filter.NextUnsafe(out EntityRef piranhaPlantEntity, out PiranhaPlant* piranhaPlant, out Enemy* enemy)) {
                var breakable = f.Unsafe.GetPointer<BreakableObject>(breakableEntity);
                if (piranhaPlant->Pipe == breakableEntity && newHeight != breakable->OriginalHeight) {
                    enemy->DisableRespawning = true;
                    if (enemy->IsAlive) {
                        piranhaPlant->Kill(f, piranhaPlantEntity, EntityRef.None, EnemyKillReason.Special);
                    }
                    enemy->RespawnTimer = 0;
                }
            }
        }

        public void OnIceBlockBroken(Frame f, EntityRef brokenIceBlock, IceBlockBreakReason breakReason, EntityRef attacker) {
            var iceBlock = f.Unsafe.GetPointer<IceBlock>(brokenIceBlock);
            if (f.Unsafe.TryGetPointer(iceBlock->Entity, out PiranhaPlant* piranhaPlant)) {
                piranhaPlant->Kill(f, iceBlock->Entity, brokenIceBlock, EnemyKillReason.Special);
            }
        }

        public void OnStageReset(Frame f, QBoolean full) {
            var filter = f.Filter<PiranhaPlant, Enemy>();
            while (filter.NextUnsafe(out EntityRef entity, out PiranhaPlant* piranhaPlant, out Enemy* enemy)) {
                enemy->DisableRespawning = false;
                if (!enemy->IsAlive && enemy->RespawnTimer <= 0) {
                    piranhaPlant->Respawn(f, entity);
                }
            }
        }
    }
}