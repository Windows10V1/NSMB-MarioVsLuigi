using Photon.Deterministic;
using System;

namespace Quantum {
    public unsafe class BreakableBrickTile : StageTile, IInteractableTile {

#if QUANTUM_UNITY
        public UnityEngine.Color ParticleColor;
#endif

        public BreakableBy BreakingRules = BreakableBy.SmallMarioDrill | BreakableBy.LargeMario | BreakableBy.LargeMarioGroundpound | BreakableBy.LargeMarioDrill | BreakableBy.MegaMario | BreakableBy.Shells | BreakableBy.Bombs | BreakableBy.Projectiles | BreakableBy.SmallWario | BreakableBy.LargeWario | BreakableBy.MegaMarioPunch;
        public bool BumpIfNotBroken;
        public FPVector2 BumpSize = new FPVector2(FP._0_50, FP._0_50);
        public FPVector2 BumpOffset = FPVector2.Zero;

        // [SerializeField] private Vector2Int tileSize = Vector2Int.one;

        public virtual bool Interact(Frame f, EntityRef entity, InteractionDirection direction, IntVector2 tilePosition, StageTileInstance tileInstance, out bool playBumpSound) {
            bool doBreak = false;
            bool doBump = true;
            bool allowSelfDamage = false;
            playBumpSound = false;

            bool brokenByMega = false;
            EntityRef bumpOwner = default;
            if (f.Unsafe.TryGetPointer(entity, out MarioPlayer* mario)) {
                bool sprintHeld = false;
                if (mario->PlayerRef.IsValid) {
                    Input* sprintInput = f.GetPlayerInput(mario->PlayerRef);
                    sprintHeld = sprintInput != null && sprintInput->Sprint.IsDown;
                }
                if (direction == InteractionDirection.Down && mario->IsGroundpoundActive && sprintHeld && mario->IsWario(f)) {
                    BreakableBy warioRule = mario->CurrentPowerupState < PowerupState.Mushroom ? BreakableBy.SmallWario : BreakableBy.LargeWario;
                    if (BreakingRules.HasFlag(warioRule)) {
                        doBreak = true;
                        brokenByMega = true;
                    }
                }
                if (!doBreak) {
                    if (mario->CurrentPowerupState < PowerupState.Mushroom) {
                        doBreak = direction switch {
                            // Small Mario
                            InteractionDirection.Down when mario->IsGroundpoundActive => BreakingRules.HasFlag(BreakableBy.SmallMarioGroundpound),
                            InteractionDirection.Down when mario->IsDrilling => BreakingRules.HasFlag(BreakableBy.SmallMarioDrill),
                            InteractionDirection.Up => BreakingRules.HasFlag(BreakableBy.SmallMario),
                            _ => false
                        };
                    } else if (mario->CurrentPowerupState == PowerupState.MegaMushroom) {
                        // Mega Mario
                        doBreak = BreakingRules.HasFlag(BreakableBy.MegaMario);
                        brokenByMega = true;
                    } else if (mario->IsInShell) {
                        // Blue Shell
                        doBreak = BreakingRules.HasFlag(BreakableBy.Shells);
                    } else {
                        doBreak = direction switch {
                            // Large Mario
                            InteractionDirection.Down when mario->IsGroundpoundActive => BreakingRules.HasFlag(BreakableBy.LargeMarioGroundpound),
                            InteractionDirection.Down when mario->IsDrilling => BreakingRules.HasFlag(BreakableBy.LargeMarioDrill),
                            InteractionDirection.Up => BreakingRules.HasFlag(BreakableBy.LargeMario),
                            _ => false
                        };
                    }
                }
                bumpOwner = entity;
            } else if (f.Unsafe.TryGetPointer(entity, out Koopa* koopa) && koopa->IsKicked) {
                doBreak = BreakingRules.HasFlag(BreakableBy.Shells);
                doBump = true;
                bumpOwner = f.Unsafe.GetPointer<Holdable>(entity)->PreviousHolder;
                allowSelfDamage = true;

            } else if (f.Has<Bobomb>(entity)) {
                doBreak = BreakingRules.HasFlag(BreakableBy.Bombs);
                doBump = false;
            } else if (f.Unsafe.TryGetPointer(entity, out Projectile* projectile)) {
                var projectileAsset = f.FindAsset(projectile->Asset);

                if (projectileAsset.BreakBreakableTiles) {
                    doBreak = BreakingRules.HasFlag(BreakableBy.Projectiles);
                }
            }

            var stage = f.FindAsset<VersusStageData>(f.Map.UserAsset);
            if (doBreak) {
                if (direction is not InteractionDirection.Left or InteractionDirection.Right) {
                    BlockBumpSystem.Bump(f, QuantumUtils.RelativeTileToWorldRounded(stage, tilePosition), bumpOwner, allowSelfDamage, direction != InteractionDirection.Down);
                }
                f.Events.TileBroken(entity, tilePosition, tileInstance, brokenByMega, direction);
                stage.SetTileRelative(f, tilePosition, default);

            } else if (BumpIfNotBroken && doBump) {
                Bump(f, stage, tilePosition, tileInstance, direction, bumpOwner, allowSelfDamage);
            } else {
                playBumpSound = true;
            }

            return doBreak;
        }

        public static void Bump(Frame f, VersusStageData stage, IntVector2 tilePosition, StageTileInstance result, InteractionDirection direction, EntityRef owner, bool allowSelfDamage, AssetRef<EntityPrototype> powerup = default) {
            if (stage == null) {
                stage = f.FindAsset<VersusStageData>(f.Map.UserAsset);
            }
            Bump(f, stage, tilePosition, stage.GetTileRelative(f, tilePosition).Tile, result, direction, owner, allowSelfDamage, powerup);
        }

        public static void Bump(Frame f, VersusStageData stage, IntVector2 tilePosition, AssetRef<StageTile> tile, StageTileInstance result, InteractionDirection direction, EntityRef owner, bool allowSelfDamage, AssetRef<EntityPrototype> powerup = default) {
            if (stage == null) {
                stage = f.FindAsset<VersusStageData>(f.Map.UserAsset);
            }
            EntityRef newEntity = f.Create(f.SimulationConfig.BlockBumpPrototype);
            var blockBump = f.Unsafe.GetPointer<BlockBump>(newEntity);
            var transform = f.Unsafe.GetPointer<Transform2D>(newEntity);

            transform->Position = QuantumUtils.RelativeTileToWorld(f, tilePosition) + FPVector2.One * FP._0_25;
            blockBump->Origin = transform->Position;
            blockBump->StartTile = tile;
            blockBump->ResultTile = result;
            blockBump->Powerup = powerup;
            blockBump->IsDownwards = direction == InteractionDirection.Down;
            blockBump->Tile = tilePosition;
            blockBump->Owner = owner;
            blockBump->AllowSelfDamage = allowSelfDamage;
            blockBump->HasBumped = direction is InteractionDirection.Left or InteractionDirection.Right;

            stage.SetTileRelative(f, tilePosition, new StageTileInstance {
                Tile = f.SimulationConfig.InvisibleSolidTile,
            });
        }

        [Flags]
        public enum BreakableBy {
            SmallMario = 1 << 0,
            SmallMarioGroundpound = 1 << 1,
            SmallMarioDrill = 1 << 2,
            LargeMario = 1 << 3,
            LargeMarioGroundpound = 1 << 4,
            LargeMarioDrill = 1 << 5,
            MegaMario = 1 << 6,
            Shells = 1 << 7,
            Bombs = 1 << 8,
            Projectiles = 1 << 9,
            SmallWario = 1 << 10,
            LargeWario = 1 << 11,
            MegaMarioPunch = 1 << 12,
        }
    }
}