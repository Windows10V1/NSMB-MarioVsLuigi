using Photon.Deterministic;

namespace Quantum {
    public unsafe class BreakableObjectSystem : SystemSignalsOnly, ISignalOnStageReset {

        public override void OnInit(Frame f) {
            f.Context.Interactions.Register<MarioPlayer, BreakableObject>(f, OnMarioBreakableObjectInteract);
            f.Context.RegisterPreContactCallback(f, OnMarioBreakableObjectPreContact);
        }

        public static bool TryInteraction(Frame f, EntityRef marioEntity, EntityRef breakableObjectEntity, in PhysicsContact? contact = null) {
            var mario = f.Unsafe.GetPointer<MarioPlayer>(marioEntity);
            if (mario->IsDead) {
                return true;
            }

            bool isMega = mario->CurrentPowerupState == PowerupState.MegaMushroom;
            bool isSpecialWarioGroundpound = !isMega && mario->IsGroundpoundActive && mario->IsWario(f);
            if (isSpecialWarioGroundpound) {
                bool sprintHeld = false;
                if (mario->PlayerRef.IsValid) {
                    Input* sprintInput = f.GetPlayerInput(mario->PlayerRef);
                    sprintHeld = sprintInput != null && sprintInput->Sprint.IsDown;
                }
                isSpecialWarioGroundpound &= sprintHeld;
            }
            if (!isMega && !isSpecialWarioGroundpound) {
                return true;
            }

            var breakable = f.Unsafe.GetPointer<BreakableObject>(breakableObjectEntity);
            var breakableCollider = f.Unsafe.GetPointer<PhysicsCollider2D>(breakableObjectEntity);
            var breakableTransform = f.Unsafe.GetPointer<Transform2D>(breakableObjectEntity);
            FPVector2 breakableUp = FPVector2.Rotate(FPVector2.Down, breakableTransform->Rotation);

            FPVector2 effectiveNormal;
            if (contact != null && breakable->IsStompable) {
                effectiveNormal = -contact.Value.Normal;
            } else {
                var marioTransform = f.Unsafe.GetPointer<Transform2D>(marioEntity);
                int direction = QuantumUtils.WrappedDirectionSign(f, breakableTransform->Position, marioTransform->Position);
                effectiveNormal = (direction == 1) ? FPVector2.Right : FPVector2.Left;
            }

            FP dot = FPVector2.Dot(effectiveNormal, breakableUp);
            if (dot > Constants.PhysicsGroundMaxAngleCos) {
                // Hit the top of a pipe
                // Shrink by 1, if we can.
                if (!breakable->IsDestroyed && breakable->CurrentHeight >= breakable->MinimumHeight + 1 && (breakable->CurrentHeight - 1 > 0)) {    
                    if (mario->IsGroundpoundActive) {
                        // Groundpound
                        ChangeHeight(f, breakableObjectEntity, breakable, breakableCollider, breakable->CurrentHeight - 1, null);
                        return false;
                    }

                    var physicsObject = f.Unsafe.GetPointer<PhysicsObject>(marioEntity);
                    if (FPVector2.Dot(breakableUp, physicsObject->Velocity) > 8) { // TODO: magic value
                        // Single stomp
                        ChangeHeight(f, breakableObjectEntity, breakable, breakableCollider, breakable->CurrentHeight - 1, null);
                        return true;
                    }
                }
                return true;
            } else if (dot > -Constants.PhysicsGroundMaxAngleCos) {
                // Hit the side of a pipe
                if (breakable->IsDestroyed || breakable->CurrentHeight <= breakable->MinimumHeight) {
                    return false;
                }

                f.Events.BreakableObjectBroken(breakableObjectEntity, marioEntity, effectiveNormal, breakable->CurrentHeight - breakable->MinimumHeight);
                ChangeHeight(f, breakableObjectEntity, breakable, breakableCollider, breakable->MinimumHeight, true);
                breakable->IsDestroyed = true;
                return false;
            }

            return true;
        }

        public static void ChangeHeight(Frame f, EntityRef entity, BreakableObject* breakable, PhysicsCollider2D* collider, FP newHeight, bool? broken) {
            newHeight = FPMath.Max(newHeight, breakable->MinimumHeight);
            breakable->CurrentHeight = newHeight;
            if (broken.HasValue) {
                breakable->IsBroken = broken.Value;
            }

            collider->Shape.Box.Extents = new(collider->Shape.Box.Extents.X, newHeight / 4);
            collider->Shape.Centroid.Y = newHeight / 4;
            collider->Enabled = newHeight > 0;

            f.Signals.OnBreakableObjectChangedHeight(entity, newHeight);
        }

        #region Interactions
        private void OnMarioBreakableObjectInteract(Frame f, EntityRef marioEntity, EntityRef breakableEntity) {
            TryInteraction(f, marioEntity, breakableEntity);
        }

        private void OnMarioBreakableObjectPreContact(Frame f, VersusStageData stage, EntityRef entity, PhysicsContact contact, ref bool keepContacts) {
            if (f.Has<MarioPlayer>(entity) && f.Has<BreakableObject>(contact.Entity)) {
                keepContacts = TryInteraction(f, entity, contact.Entity, contact);
            }
        }
        #endregion

        #region Signals
        public void OnStageReset(Frame f, QBoolean full) {
            var filter = f.Filter<BreakableObject, PhysicsCollider2D>();
            while (filter.NextUnsafe(out EntityRef entity, out BreakableObject* breakable, out PhysicsCollider2D* collider)) {
                ChangeHeight(f, entity, breakable, collider, breakable->OriginalHeight, false);
                breakable->IsDestroyed = false;
            }
        }
        #endregion
    }
}
